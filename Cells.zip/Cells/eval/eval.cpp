#include <iostream>
#include <stack>
#include <sstream>
#include <cmath> // For pow()
using namespace std;

// Helper function to perform integer floor division
int floorDivide(int a, int b) {
    if (a * b < 0 && a % b != 0) { // If the signs differ and there's a remainder
        return a / b - 1;          // Adjust result to round down
    }
    return a / b;
}

// Function to evaluate a postfix expression
int evalPostfix(const string &expr) {
    stack<int> s;
    stringstream ss(expr);
    string token;

    while (ss >> token) {
        if (isdigit(token[0]) || (token[0] == '-' && token.size() > 1)) {
            // If the token is a number (positive or negative)
            s.push(stoi(token));
        } else if (token.size() == 1 && string("+-*/^").find(token) != string::npos) {
            // If the token is an operator
            if (s.size() < 2) {
                cerr << "Error: Malformed postfix expression." << endl;
                return -1;
            }
            int b = s.top(); s.pop();
            int a = s.top(); s.pop();
            if (token == "+") s.push(a + b);
            else if (token == "-") s.push(a - b);
            else if (token == "*") s.push(a * b);
            else if (token == "/") s.push(floorDivide(a, b)); // Use floor division
            else if (token == "^") s.push(pow(a, b));
        } else {
            cerr << "Error: Unknown token " << token << endl;
            return -1;
        }
    }

    // At the end, there should be exactly one value in the stack
    if (s.size() != 1) {
        cerr << "Error: Malformed postfix expression." << endl;
        return -1;
    }

    return s.top();
}

int main(int argc, char *argv[]) {
    if (argc != 2) {
        cerr << "Usage: ./eval <postfix_expression>" << endl;
        return 1;
    }

    // Evaluate the postfix expression
    string expr = argv[1];
    int result = evalPostfix(expr);

    // Print the result
    cout << result << endl;
    return 0;
}


